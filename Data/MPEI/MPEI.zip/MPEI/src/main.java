

public class main {
    public static void main(String[] args){
       // ExecuteMinHash test = new ExecuteMinHash(2,200);
       // test.addDocument("teste hehe pois la roger delta gosto de pila");
       // test.addDocument("palavra eu sou o ricardo e gosto de pila");
        //System.out.println(test.similarity(0,1));
        //StochasticCounter test2 = new StochasticCounter();
        //test2.analyzeDocument("palavra palavra eu sou o o ricardo e gosto de pila");
        //System.out.println(test2.numberOfOcurrences("palavra"));

        //TestBloomFilter test = new TestBloomFilter();
        //test.workShift();
       //test.testCountries(15);
        //test.testRandomStrings(1000,40,8000,3);
        //test.testRandomStrings(10000,40,8000,3);
        //test.defaultTestRandomStrings();

        TestCountingFilter test = new TestCountingFilter();
        test.workShift();
        //test.pokedexTest();
       // CountingBloomFilter BF = new CountingBloomFilter(1000,10);
       // BF.insert("pika");
       // System.out.println(BF.verify("pika"));
       // BF.remove("pika");
       // System.out.println(BF.verify("pika"));
    }
}
