import java.util.*;

public class MinHash {
    int numberOfHashFunctions; //number of hashing functions
    int shingleLength=5;  // length of each shingle
    int totalNumberOfShingles; // total number ( calculated using a small calculation )
    ArrayList<String> documentList; //arraylist of each word that comes in the string
    ArrayList<Shingle> shingles; //arraylist of all the shingles
    int minHashList[];

    //constructor
    public MinHash(int numberOfHashFunctions, String document){
        ArrayList<String> documentList = new ArrayList<String>(Arrays.asList(document.split(" ")));
        this.numberOfHashFunctions=numberOfHashFunctions;
        totalNumberOfShingles=documentList.size()-shingleLength+1;
        shingles = new ArrayList<Shingle>();
        this.documentList=documentList;
        minHashList = new int[numberOfHashFunctions];

    }
    // main minhash function
    public void populateMinHashList(){
        shingling();
        hashing();
    }

    // takes care of the hashing for each shingle
    private void hashing(){
       for(int i = 0; i <numberOfHashFunctions ; i++){
           minHashList[i]=hashingAux(i);
       }
    }
    //  hashing shingles
    private int hashingAux(int hashingfunction){
        String tmp ;
        int minhash=Integer.MAX_VALUE;
        for(int i = 0; i<shingles.size();i++) {
            tmp = "";
            for(int j = 0 ; j<shingleLength; j++) {
                tmp = tmp.concat(shingles.get(i).words[j]);
            }
            int hashcode = tmp.hashCode()^hashingfunction+20;
            shingles.get(i).hash=Math.abs(hashcode) % 20; // 20 seems like a good number

            if(shingles.get(i).hash<minhash)
                minhash=shingles.get(i).hash;
        }
        return minhash;
    }

    // separating the initial document into shingles
    private void shingling(){
        Shingle temp;
        int documentPointer=0;
        for(int i = 0; i<totalNumberOfShingles; i++){
            temp = new Shingle(shingleLength);
            temp.id=i;
            for(int j = 0 ; j < shingleLength; j++){
                temp.words[j]= documentList.get(documentPointer+j);
            }
            shingles.add(temp);
            documentPointer++;
        }
    }


    // JACARD

    public double jaccardCoefficient(Set<Integer> setA, Set<Integer> setB){

        // intersection
        Set<Integer> intersection = new HashSet<Integer>(setA);
        intersection.retainAll(setB);

        // union
        Set<Integer> union = new HashSet<Integer>(setA);
        union.addAll(setB);

        // non division by 0
        if(union.isEmpty())
            return 0;

        return (double) intersection.size() / union.size();
    }
}

//Aux class
class Shingle {
    String words[];
    int hash;
    int id;
    public Shingle(int size){
        words = new String[size];
    }
}