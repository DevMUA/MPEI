public class MasterTest {

    public MasterTest(){

    }
}
